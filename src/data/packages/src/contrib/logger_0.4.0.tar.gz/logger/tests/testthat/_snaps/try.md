# %except% logs errors and returns default value

    Code
      out <- f()
    Output
      except / global / logger / f / f()
      WARN Running '1' as 'FunDoesNotExist(1:10)' failed: 'could not find function "FunDoesNotExist"'

