## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----cleanup, include = FALSE-------------------------------------------------
logger:::namespaces_reset()

