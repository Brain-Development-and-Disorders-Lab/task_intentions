###
### $Id: ceil.R 29 2022-05-30 23:02:22Z proebuck $
###
### Rounds to the nearest integer.
###


##-----------------------------------------------------------------------------
ceil <- function(x) {
    ceiling(x)
}

