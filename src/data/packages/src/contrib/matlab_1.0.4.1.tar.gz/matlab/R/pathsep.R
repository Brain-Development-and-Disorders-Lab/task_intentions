###
### $Id: pathsep.R 22 2022-05-30 18:03:47Z proebuck $
###
### Path separator for this platform.
###


##-----------------------------------------------------------------------------
pathsep <- .Platform$path.sep

