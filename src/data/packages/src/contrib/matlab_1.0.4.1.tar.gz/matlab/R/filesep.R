###
### $Id: filesep.R 22 2022-05-30 18:03:47Z proebuck $
###
### Directory separator for this platform.
###


##-----------------------------------------------------------------------------
filesep <- .Platform$file.sep

