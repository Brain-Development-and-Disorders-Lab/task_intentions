# errors

    ! `options("cli.width")` must be an integer scalar.
    i `options("cli.width")` is a character vector.

---

    ! `options("cli.width")` cannot be `NA`.

---

    ! `options("cli.width")` must be a positive integer and not -100.

